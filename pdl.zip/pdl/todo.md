# add the collapse/expand to lists
# allow to exec from contexte menu through Extension
https://medium.com/@rmmmsy/your-first-visual-studio-code-extension-ce8e040ba8ca

