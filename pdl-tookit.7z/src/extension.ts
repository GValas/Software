// The module 'vscode' contains the VS Code extensibility API
// Import the module and reference it with the alias vscode in your code below
import * as vscode from 'vscode';

const gnpHostPorts = [
	"gnp-histo:8000 | MDD",
	"gnp-histo:1230 | CPS",
	"localhost:9999 | local GNP broker"
]

// gnp request
async function RunGnpRequest() {
	const gnpServer = await vscode.window.showQuickPick(
		gnpHostPorts,
		{ "placeHolder": "Select your GNP host:port" }
	);
	await vscode.window.showInformationMessage(`server : ${gnpServer}`);
};

// extension activation
export function activate(context: vscode.ExtensionContext) {
	vscode.commands.registerCommand('pdl-tooolkit.run-gnp-request', () => RunGnpRequest());

	vscode.window.registerTreeDataProvider("pdl.services", {
		getChildren() {
			return gnpHostPorts;
		},

		getTreeItem(element: string) {
			return {
				label: element, 
				command: {
					command: "markdown.showPreview",
					title: "tst",
					arguments: [
						element
					]

				}
				
			};
		}
	});
}

// extension desactivation
export function deactivate() { }
