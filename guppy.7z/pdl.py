# elementary pdl types
from typing import TypeVar, Generic, List, Dict, Union
Num = float
Str = str
Vec = List[Num]
Txt = List[Str]
Key = str 
Val = TypeVar('Val', Num, Str, Vec, Txt)

# Pdl is a regular dictionary with keys & types constraints 
class Dict(Dict[Key, Val]):

    def __init__(self, *args, **kwargs):
        super(Dict, self).__init__(*args, **kwargs)
        for key in self.list_keys():
            Dict.check_key(key)

    @staticmethod
    def check_key(key: Key):
        if not (type(key) is Key and key.count('.') <= 1):
            raise Exception('Invalid key : ' + str(key))

    def list_keys(self):
        return set(self.keys())

    def list_objects(self):
        return {key.split('.')[0] if '.' in key else '' for key in self.keys()}

    def __setitem__(self, key, value):
        Dict.check_key(key)
        super(Dict, self).__setitem__(key, value)

    # dict[key] where key = 'a.b[0].c'
    def __getitem__(self, item):

        elts = item.split('.')

        if(len(elts) <= 2):
            pos = item.split('#')
            val = super(Dict, self).__getitem__(pos[0])
            return val[int(pos[1])] if(len(pos) > 1) else val
        else:
            val = self[elts[0] + '.' + elts[1]]
            return self[val + '.' + '.'.join(elts[2:])]

    def read_pdl(self, file):
        pass

    def write_pdl(self, file):
        pass

    def gnp_exec(self, active_object, host, port):
        pass

    def http_exec(self):
        # https://www.datacamp.com/community/tutorials/making-http-requests-in-python
        pass
