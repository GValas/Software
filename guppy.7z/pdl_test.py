import pytest
from guppy import pdl


@pytest.fixture
def d():
    return pdl.Dict({'o1.a1': ['o2', 'o3'],
                    'o2.a1': 'o3',
                    'o3.a1': 3})


def test_getitem(d):
    assert d['o1.a1'] == ['o2', 'o3']
    assert d['o1.a1#0'] == 'o2'
    assert d['o1.a1#0.a1'] == 'o3'
    assert d['o1.a1#1.a1'] == 3


def test_list_keys(d):
    assert d.list_keys() == {'o1.a1', 'o2.a1', 'o3.a1'}


def test_list_objects(d):
    assert d.list_objects() == {'o1', 'o2', 'o3'}
