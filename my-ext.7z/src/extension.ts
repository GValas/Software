import * as vscode from 'vscode';
import { Helper } from './Helper';

export function activate(context: vscode.ExtensionContext) {
	context.subscriptions.push(
		vscode.commands.registerCommand('my-ext.hello', async () => {
			const data = await Helper.getDataFromAPI();
			vscode.window.showInformationMessage(data);
		})
	); 
} 

export function deactivate() { }