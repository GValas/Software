import fetch from "node-fetch";


export class Helper {

    static async getDataFromAPI(): Promise<string> {
        let response = await fetch("https://api.github.com/users/up1");
        let data = await response.json();
        let ret = JSON.stringify(data, null, "\t");
        return ret;
    }


}